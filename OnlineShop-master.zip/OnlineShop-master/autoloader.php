<?php


require($_SERVER['DOCUMENT_ROOT'].'/OnlineShop/resources/class/activeRecordInterface.php');
require($_SERVER['DOCUMENT_ROOT'].'/OnlineShop/resources/class/activeRecord.php');
require($_SERVER['DOCUMENT_ROOT'].'/OnlineShop/resources/class/User.php');
require($_SERVER['DOCUMENT_ROOT'].'/OnlineShop/resources/class/Admin.php');
require($_SERVER['DOCUMENT_ROOT'].'/OnlineShop/resources/class/Item.php');
require($_SERVER['DOCUMENT_ROOT'].'/OnlineShop/resources/class/Image.php');
require($_SERVER['DOCUMENT_ROOT'].'/OnlineShop/resources/class/Message.php');
require($_SERVER['DOCUMENT_ROOT'].'/OnlineShop/resources/class/Order.php');
require($_SERVER['DOCUMENT_ROOT'].'/OnlineShop/resources/config.php');
