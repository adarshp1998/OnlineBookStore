<?php
define('TITLE', "LogIn");
include($_SERVER['DOCUMENT_ROOT'].'/OnlineShop/structure/header.php');
?>

<h1>Contact us</h1>

<div class="container">
<ul class="list-group-item-info">
    <li>lkupinski@gmail.com</li>
    <li>mbazyl2@gmail.com</li>
</ul>
</div>
<?php
include($_SERVER['DOCUMENT_ROOT'].'/OnlineShop/structure/footer.php');
?>