# OnlineShop
  The project is a simple online shop made during course in @CodersLab using PHP and JavaScript.

  1. User can register new account and log in.
  2. User can browse shop and add items to cart.
  3. Cart displays selected items and calculates total price. User can make order.
  4. User have access to orders history. (in progress)
  5. Logging as admin shows additional admin panel.
  6. Admin can edit or delete users and items.
  7. Admin can send messages to users.
