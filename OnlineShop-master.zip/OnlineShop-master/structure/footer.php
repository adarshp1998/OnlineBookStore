

</div>
<?php $path = $_SERVER['DOCUMENT_ROOT']; ?>
<script src="<?php $path?>/OnlineShop/structure/js/jquery-3.2.0.min.js"></script>
<script src="<?php $path?>/OnlineShop/structure/js/bootstrap.min.js"></script>
</body>

</html>